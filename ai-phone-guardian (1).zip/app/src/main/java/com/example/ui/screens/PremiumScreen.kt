package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CleanerViewModel

private val GrayText = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumScreen(
    viewModel: CleanerViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPremium by viewModel.isPremium.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Premium Account", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Premium Shield Header Icon
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .background(
                        if (isPremium) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        else MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPremium) Icons.Rounded.VerifiedUser else Icons.Rounded.Star,
                    contentDescription = "Premium star",
                    tint = if (isPremium) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(50.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isPremium) "AI Guardian Pro Active" else "Go AI Guardian Pro",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black)
                )
                Text(
                    text = if (isPremium) "Thank you for supporting offline local optimization!" else "Unlock professional deep scanning utilities and clear all ads.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = GrayText,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            // Benefits checklist card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PremiumBenefitRow(
                        title = "100% Offline Ad-Free",
                        description = "Simulated Google AdMob banners and interstitials are completely disabled.",
                        icon = Icons.Rounded.Block,
                        iconColor = Color(0xFFF87171)
                    )
                    PremiumBenefitRow(
                        title = "Extra Diagnostic Reports",
                        description = "Unlock deep sector audits and precise files modification indexes.",
                        icon = Icons.Rounded.Article,
                        iconColor = Color(0xFF22D3EE)
                    )
                    PremiumBenefitRow(
                        title = "Automatic Scheduler",
                        description = "Perform standard cleanup in the background when the phone is idle.",
                        icon = Icons.Rounded.Timelapse,
                        iconColor = Color(0xFF34D399)
                    )
                }
            }

            // Active / Toggle Button
            Button(
                onClick = { viewModel.togglePremium() },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPremium) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp))
                    .testTag("premium_upgrade_button")
            ) {
                Text(
                    text = if (isPremium) "RESTORE TO FREE VERSION (DEBUG)" else "UPGRADE TO PRO ($1.99/mo)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = if (isPremium) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary
                )
            }

            // Monetization internet status note
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Monetization & Offline Principle Details:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Ads are served ONLY when device has active internet access.\n" +
                               "• Internet Status: ${if (isInternetAvailable) "ONLINE (Ads will display)" else "OFFLINE (Working 100% offline without ads)"}\n" +
                               "• No data is uploaded or fetched; all cleaning files indexing is performed locally.",
                        fontSize = 10.sp,
                        color = GrayText,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PremiumBenefitRow(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(iconColor.copy(alpha = 0.1f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = GrayText
            )
        }
    }
}
