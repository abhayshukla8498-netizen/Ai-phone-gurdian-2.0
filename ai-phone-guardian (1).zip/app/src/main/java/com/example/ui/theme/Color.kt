package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palettes (Clean, medical/utility emerald)
val LightPrimary = Color(0xFF006E51)
val LightSecondary = Color(0xFF4C6356)
val LightTertiary = Color(0xFF3F6375)
val LightBackground = Color(0xFFF4F7F5)
val LightSurface = Color(0xFFFFFFFF)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF191C1A)

// Dark Theme Palettes (Elegant Dark)
val DarkPrimary = Color(0xFF22D3EE) // Tech Cyan
val DarkSecondary = Color(0xFF06B6D4) // Medium Cyan
val DarkTertiary = Color(0xFFFBBF24) // Gold/Amber Premium Accent
val DarkBackground = Color(0xFF0A0C10) // Ultra Deep Midnight Slate
val DarkSurface = Color(0xFF161A22) // Sleek slate-800 card color
val DarkOnPrimary = Color(0xFF0A0C10) // High contrast dark text on Cyan
val DarkOnBackground = Color(0xFFF1F5F9) // Slate-100 style text

// Special Status Accents
val SpeedColor = Color(0xFF22D3EE)
val StorageColor = Color(0xFF3B82F6)
val JunkColor = Color(0xFFF87171)
val BatteryColor = Color(0xFF34D399)
val OrangeColor = Color(0xFFFBBF24)
val GrayText = Color(0xFF94A3B8)

