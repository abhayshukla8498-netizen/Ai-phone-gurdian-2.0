package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CleanerViewModel

private val GrayText = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleanerScreen(
    viewModel: CleanerViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeCleanType by viewModel.activeCleanType.collectAsState()
    val isCleaningInProgress by viewModel.isCleaningInProgress.collectAsState()
    val isCleaningCompleted by viewModel.isCleaningCompleted.collectAsState()
    val progress by viewModel.cleaningProgress.collectAsState()
    val currentFile by viewModel.currentlyCleaningFile.collectAsState()
    val logs by viewModel.cleanedLogs.collectAsState()

    // Retrieve active checked lists
    val junkList by viewModel.junkList.collectAsState()
    val largeFiles by viewModel.largeFiles.collectAsState()
    val duplicateGroups by viewModel.duplicateGroups.collectAsState()

    var showConfirmDialog by remember { mutableStateOf(false) }
    val logListState = rememberLazyListState()

    // Animated angle for cleaning sweeps
    val infiniteTransition = rememberInfiniteTransition(label = "clean_rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Calculate total items and sizes
    val checkedJunks = remember(junkList, activeCleanType) {
        if (activeCleanType == "junk" || activeCleanType == "all") junkList.filter { it.checked } else emptyList()
    }
    val checkedLarge = remember(largeFiles, activeCleanType) {
        if (activeCleanType == "large" || activeCleanType == "all") largeFiles.filter { it.checked } else emptyList()
    }
    val checkedDups = remember(duplicateGroups, activeCleanType) {
        if (activeCleanType == "duplicates" || activeCleanType == "all") {
            duplicateGroups.flatMap { it.photos }.filter { it.checked }
        } else {
            emptyList()
        }
    }

    val totalSize = checkedJunks.sumOf { it.size } + checkedLarge.sumOf { it.size } + checkedDups.sumOf { it.size }
    val totalCount = checkedJunks.size + checkedLarge.size + checkedDups.size

    // Auto scroll logs during deletion
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            logListState.animateScrollToItem(logs.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isCleaningInProgress) "AI Secure Shredding..." else "Safe File Shredder",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    if (!isCleaningInProgress) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(imageVector = Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isCleaningInProgress || isCleaningCompleted) {
                // ==========================================
                // CLEANING PROGRESS ANIMATION VIEW (RUNNING)
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isCleaningCompleted) "SECURE PURGE COMPLETE" else "AI ENCRYPTION PURGE IN PROGRESS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Cyber Ring Progress animation
                    Box(
                        modifier = Modifier.size(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val themePrimary = MaterialTheme.colorScheme.primary
                        val themeSecondary = MaterialTheme.colorScheme.secondary
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 10.dp.toPx()
                            // Track Circle
                            drawCircle(
                                color = themePrimary.copy(alpha = 0.08f),
                                style = Stroke(width = strokeWidth)
                            )
                            // Animated sweeping sector
                            drawArc(
                                color = themePrimary,
                                startAngle = rotationAngle - 90f,
                                sweepAngle = 90f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                            // Active Progress Fill
                            drawArc(
                                color = themeSecondary,
                                startAngle = -90f,
                                sweepAngle = progress * 360f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${(progress * 100).toInt()}%",
                                style = MaterialTheme.typography.displayMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = (-1).sp
                                ),
                                color = Color.White
                            )
                            Text(
                                text = if (isCleaningCompleted) "SECURED" else "SHREDDING",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = GrayText
                            )
                        }
                    }

                    // Current file path indicator
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Processing File Descriptor:",
                            style = MaterialTheme.typography.bodySmall,
                            color = GrayText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentFile.ifEmpty { "Finalizing storage registers..." },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }

                    // Shell logs
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black)
                    ) {
                        Box(modifier = Modifier.padding(14.dp)) {
                            LazyColumn(
                                state = logListState,
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(logs) { log ->
                                    Text(
                                        text = log,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = if (log.contains("complete") || log.contains("Erased") || log.contains("Permanently")) {
                                            Color(0xFF34D399) // Clean green
                                        } else {
                                            Color(0xFF22D3EE) // Cool cyan
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // ==========================================
                // PREPARATION VIEW (LISTING SELECTED FILES)
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Ready to permanently purge",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = GrayText
                                )
                                Text(
                                    text = viewModel.formatSize(totalSize),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "$totalCount Items",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "FILES SELECTED FOR DELETION:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = GrayText,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )

                    if (totalCount == 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No files selected. Go back and select files to clean.",
                                color = GrayText,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            items(checkedJunks) { item ->
                                SelectedFileRow(
                                    name = item.name,
                                    desc = item.description,
                                    sizeStr = viewModel.formatSize(item.size),
                                    icon = Icons.Rounded.DeleteSweep,
                                    iconColor = MaterialTheme.colorScheme.primary
                                )
                            }
                            items(checkedLarge) { item ->
                                SelectedFileRow(
                                    name = item.name,
                                    desc = item.path,
                                    sizeStr = viewModel.formatSize(item.size),
                                    icon = Icons.Rounded.FindInPage,
                                    iconColor = MaterialTheme.colorScheme.secondary
                                )
                            }
                            items(checkedDups) { photo ->
                                SelectedFileRow(
                                    name = "IMG_${photo.id}.jpg",
                                    desc = "/storage/emulated/0/DCIM/Camera/IMG_DUP_${photo.id}.jpg",
                                    sizeStr = viewModel.formatSize(photo.size),
                                    icon = Icons.Rounded.PhotoLibrary,
                                    iconColor = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }

                        Button(
                            onClick = { showConfirmDialog = true },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                                .height(56.dp)
                                .testTag("secure_purge_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = "Purge lock",
                                tint = MaterialTheme.colorScheme.onError,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SECURELY SHRED SELECTED",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.onError
                            )
                        }
                    }
                }
            }
        }
    }

    // Deletion confirmation popup dialog
    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Rounded.Warning,
                    contentDescription = "Security alert",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Permanent Deletion?",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently shred these $totalCount items from your device? This operation cannot be undone. All selected files will be securely purged on-device.",
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDialog = false
                        viewModel.startCleaningProcess {
                            onNavigateBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Yes, Delete Permanently")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("Cancel", color = GrayText)
                }
            }
        )
    }
}

@Composable
fun SelectedFileRow(
    name: String,
    desc: String,
    sizeStr: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(iconColor.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = name,
                        tint = iconColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodySmall,
                        color = GrayText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = sizeStr,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
