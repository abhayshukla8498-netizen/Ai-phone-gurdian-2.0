package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CleanerViewModel
import com.example.data.ScanStep
import kotlinx.coroutines.delay

private val GrayText = Color(0xFF94A3B8)

@Composable
fun ScanScreen(
    viewModel: CleanerViewModel,
    onFinishedScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scanStep by viewModel.scanStep.collectAsState()
    val progress by viewModel.scanProgress.collectAsState()
    val currentFile by viewModel.currentScanningFile.collectAsState()
    val logs by viewModel.scanningLogs.collectAsState()

    val logListState = rememberLazyListState()

    // Radar rotation animation
    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_rotation"
    )

    // Auto navigate on scan completion
    LaunchedEffect(scanStep) {
        if (scanStep == ScanStep.COMPLETED) {
            delay(1500) // Hold briefly so the user sees completion state
            onFinishedScan()
        }
    }

    // Auto-scroll log screen
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            logListState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "SCANNING INTERNAL STORAGES",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.5.sp
            ),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.testTag("scan_title")
        )

        // Radar Circular Animation
        Box(
            modifier = Modifier
                .size(170.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Radial background glow sweeps
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .rotate(rotationAngle)
                    .background(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // Outer cover to look like a cockpit display
            Box(
                modifier = Modifier
                    .size(142.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = when (scanStep) {
                            ScanStep.SCANNING_JUNK -> Icons.Rounded.DeleteSweep
                            ScanStep.SCANNING_LARGE -> Icons.Rounded.FindInPage
                            ScanStep.SCANNING_DUPLICATES -> Icons.Rounded.PhotoLibrary
                            ScanStep.SCANNING_APPS -> Icons.Rounded.AppRegistration
                            ScanStep.SCANNING_ANALYSIS -> Icons.Rounded.Analytics
                            else -> Icons.Rounded.Security
                        },
                        contentDescription = "Active Sweep icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${(progress * 100).toInt()}%",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
                    )
                }
            }
        }

        // Running file indicator
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Currently scanning:",
                style = MaterialTheme.typography.bodySmall,
                color = GrayText
            )
            Text(
                text = currentFile.ifEmpty { "Analyzing local file signatures..." },
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                ),
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        // Live Scanning Progress Checklist States
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProgressStepRow(
                    label = "1. Junk Cache Scanner",
                    isActive = scanStep == ScanStep.SCANNING_JUNK,
                    isDone = scanStep > ScanStep.SCANNING_JUNK
                )
                ProgressStepRow(
                    label = "2. Large Files Detector",
                    isActive = scanStep == ScanStep.SCANNING_LARGE,
                    isDone = scanStep > ScanStep.SCANNING_LARGE
                )
                ProgressStepRow(
                    label = "3. Similar Photo Finder",
                    isActive = scanStep == ScanStep.SCANNING_DUPLICATES,
                    isDone = scanStep > ScanStep.SCANNING_DUPLICATES
                )
                ProgressStepRow(
                    label = "4. App Manager Auditor",
                    isActive = scanStep == ScanStep.SCANNING_APPS,
                    isDone = scanStep > ScanStep.SCANNING_APPS
                )
                ProgressStepRow(
                    label = "5. Sector Storage Analyzer",
                    isActive = scanStep == ScanStep.SCANNING_ANALYSIS,
                    isDone = scanStep > ScanStep.SCANNING_ANALYSIS
                )
            }
        }

        // Monospace Scrolling Log console
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.Black
            )
        ) {
            Box(modifier = Modifier.padding(14.dp)) {
                LazyColumn(
                    state = logListState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(logs) { log ->
                        Text(
                            text = log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = if (log.contains("Found") || log.contains("Detected") || log.contains("completed")) {
                                Color(0xFF34D399)
                            } else {
                                Color(0xFF22D3EE)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProgressStepRow(
    label: String,
    isActive: Boolean,
    isDone: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isActive) MaterialTheme.colorScheme.primary
            else if (isDone) MaterialTheme.colorScheme.onSurface
            else GrayText
        )

        if (isDone) {
            Icon(
                imageVector = Icons.Rounded.CheckCircle,
                contentDescription = "Success tick",
                tint = Color(0xFF34D399),
                modifier = Modifier.size(20.dp)
            )
        } else if (isActive) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Circle,
                contentDescription = "Pending mark",
                tint = GrayText.copy(alpha = 0.3f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
